
// peticion al servidor de si el usuario esta logeado o no