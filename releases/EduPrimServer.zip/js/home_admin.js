window.onload = function() {
    tryPopulating();
}