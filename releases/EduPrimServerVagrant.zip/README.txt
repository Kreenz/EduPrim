entra en initialize.sh y update.sh


En las primeras lineas escribe el usuario y la password con la que accedes al git del proyecto
#---------------------------------------------
USER="tu_usuario"
PASSWORD="tu_password"
#---------------------------------------------